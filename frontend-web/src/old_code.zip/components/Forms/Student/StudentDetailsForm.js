import React from 'react'

function StudentDetailsForm() {
  return (
    <div>StudentDetailsForm</div>
  )
}

export default StudentDetailsForm