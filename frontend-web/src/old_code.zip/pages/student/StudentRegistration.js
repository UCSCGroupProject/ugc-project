import React from "react";

import StudentDetailsForm from "../../components/Forms/Student/StudentDetailsForm";

function StudentRegistration() {
  return (
    <div>
      <StudentDetailsForm />
    </div>
  );
}

export default StudentRegistration;
