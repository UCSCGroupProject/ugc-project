package com.ugc.blockchain.crypto.signing;

import org.bouncycastle.jce.interfaces.ECPublicKey;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.security.*;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class ECDSAHelper {
    public static KeyPair ellipticCurveCrypto(){
        try {
            Security.addProvider(new BouncyCastleProvider());
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("ECDSA", "BC");
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            ECGenParameterSpec params = new ECGenParameterSpec("secp192k1");
            keyPairGenerator.initialize(params, secureRandom);
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

            return keyPair;
        } catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        }

        return null;
    }

    // Use ECDSA signature and returns the result
    public static byte[] applyECDSASignature(PrivateKey privateKey, String input){
        Signature signature;
        byte[] output = new byte[0];

        try {
            signature = Signature.getInstance("ECDSA", "BC");
            signature.initSign(privateKey);
            byte[] strByte = input.getBytes();
            signature.update(strByte);
            byte[] realSignature = signature.sign();
            output = realSignature;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return output;
    }

    // Check the data is signed by the actual user based on the signature
    public static  boolean verifyECDSASignature(PublicKey publicKey, String data, byte[] signature){
        try{
            Signature ecdsaSignature = Signature.getInstance("ECDSA", "BC");
            ecdsaSignature.initVerify(publicKey);
            ecdsaSignature.update(data.getBytes());
            return ecdsaSignature.verify(signature);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static String getStringFromPublicKey(PublicKey publicKey){
        // Converting public key to byte
        byte[] byte_pubKey = publicKey.getEncoded();

        // Converting byte to String
        String str_pubKey = Base64.getEncoder().encodeToString(byte_pubKey);

        return str_pubKey;
    }

    public static PublicKey getPublicKeyFromString(String publicKey) {
        // Converting string to byte
        byte[] byte_pubKey = Base64.getDecoder().decode(publicKey);

        try{
            // Converting byte to public key
            KeyFactory factory = KeyFactory.getInstance("ECDSA", "BC");
            PublicKey pubKey = (ECPublicKey) factory.generatePublic(new X509EncodedKeySpec(byte_pubKey));
            return pubKey;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
