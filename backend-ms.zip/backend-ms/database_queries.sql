DROP DATABASE IF EXISTS auth_db;
CREATE DATABASE auth_db;
USE auth_db;
